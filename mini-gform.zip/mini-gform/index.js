const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

// Untuk file statis
app.use(express.static('public'));

// View engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Parsing form
app.use(express.urlencoded({ extended: true }));

// Form route
app.get('/', (req, res) => {
  res.render('form');
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});